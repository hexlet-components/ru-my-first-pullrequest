It is very interesting to create something new
