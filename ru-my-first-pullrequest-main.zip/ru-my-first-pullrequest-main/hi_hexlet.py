print("Hi Hexlet!")
