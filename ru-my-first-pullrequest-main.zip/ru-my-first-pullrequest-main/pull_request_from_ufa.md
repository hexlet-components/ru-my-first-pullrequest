hi from Ufa
