Message Of The Day  
Roses are red  
Violets are blue  
This Message Of The Day  
Is rythm with not.  
