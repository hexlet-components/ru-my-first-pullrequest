Write for future me
