Hi dudes
