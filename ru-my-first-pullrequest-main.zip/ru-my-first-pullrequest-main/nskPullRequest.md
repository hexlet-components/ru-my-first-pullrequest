Good day from NSK
