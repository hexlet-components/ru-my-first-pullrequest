My first pullrequest from Hithub
And my second pullrequest form PC
