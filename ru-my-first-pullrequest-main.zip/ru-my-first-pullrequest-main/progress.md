Industrial society has been a disaster for the human race.
