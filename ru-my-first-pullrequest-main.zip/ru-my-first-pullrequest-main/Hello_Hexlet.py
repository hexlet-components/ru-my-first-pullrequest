name = "I'm Dmitriy Golubev"
message = 'Hi Hexlet'
print(f'{message}, {name}. I dream of becoming a Python programmer!')