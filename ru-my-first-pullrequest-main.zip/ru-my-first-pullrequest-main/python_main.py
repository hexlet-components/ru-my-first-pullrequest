HELLO = "KARAMBA!!!)))"

print(HELLO)

