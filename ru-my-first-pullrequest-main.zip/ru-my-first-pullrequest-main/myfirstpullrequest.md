Hello, Hexlet! It's my first pull-request!
