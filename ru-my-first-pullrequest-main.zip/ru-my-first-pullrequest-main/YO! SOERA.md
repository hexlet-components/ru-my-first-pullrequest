Yo! 

If you are reading this message, just know that you are the best!
